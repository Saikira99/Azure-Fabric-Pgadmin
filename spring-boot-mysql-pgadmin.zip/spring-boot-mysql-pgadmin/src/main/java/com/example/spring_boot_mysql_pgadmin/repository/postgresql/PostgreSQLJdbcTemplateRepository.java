package com.example.spring_boot_mysql_pgadmin.repository.postgresql;

import com.example.spring_boot_mysql_pgadmin.entity.Technology;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class PostgreSQLJdbcTemplateRepository {

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public PostgreSQLJdbcTemplateRepository(@Qualifier("postgresqlJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Technology> findAll() {
        String sql = "SELECT * FROM technology";
        return jdbcTemplate.query(sql, this::mapRowToTechnology);
    }

    public Optional<Technology> findById(Long id) {
        String sql = "SELECT * FROM technology WHERE technology_id = ?";
        try {
            Technology technology = jdbcTemplate.queryForObject(sql, new Object[]{id}, this::mapRowToTechnology);
            return Optional.of(technology);
        } catch (Exception e) {
            // Log the error here
            return Optional.empty(); // Handle not found case
        }
    }

    public Technology save(Technology technology) {
        String sql = "INSERT INTO technology (technology_name, created_date, updated_date) VALUES (?, ?, ?)";

        GeneratedKeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update((Connection conn) -> {
            PreparedStatement ps = conn.prepareStatement(sql, new String[]{"technology_id"});
            ps.setString(1, technology.getName());
            ps.setDate(2, java.sql.Date.valueOf(technology.getCreatedDate()));
            ps.setDate(3, java.sql.Date.valueOf(technology.getUpdatedDate()));
            return ps;
        }, keyHolder);

        technology.setId(keyHolder.getKey().longValue()); // Set the generated ID
        return technology;
    }

    public void update(Technology technology) {
        String sql = "UPDATE technology SET technology_name = ?, updated_date = ? WHERE technology_id = ?";
        jdbcTemplate.update(sql, technology.getName(), java.sql.Date.valueOf(technology.getUpdatedDate()), technology.getId());
    }

    public void deleteById(Long id) {
        String sql = "DELETE FROM technology WHERE technology_id = ?";
        jdbcTemplate.update(sql, id);
    }

    private Technology mapRowToTechnology(ResultSet rs, int rowNum) throws SQLException {
        Technology technology = new Technology();
        technology.setId(rs.getLong("technology_id"));
        technology.setName(rs.getString("technology_name"));
        technology.setCreatedDate(rs.getDate("created_date").toLocalDate());
        technology.setUpdatedDate(rs.getDate("updated_date").toLocalDate());
        return technology;
    }
}
