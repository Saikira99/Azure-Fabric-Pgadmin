//package com.example.spring_boot_mysql_pgadmin.configuration;
//
//import org.springframework.beans.factory.annotation.Qualifier;
//import org.springframework.boot.context.properties.ConfigurationProperties;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.datasource.DriverManagerDataSource;
//
//import javax.sql.DataSource;
//
//@Configuration
//public class FabricSQLConfiguration {
//
//    @Bean(name = "fabricDataSource")
//    @ConfigurationProperties("spring.datasource.fabricwarehouse")
//    public DataSource fabricDataSource() {
//        return new DriverManagerDataSource();
//    }
//
//    @Bean(name = "fabricJdbcTemplate")
//    public JdbcTemplate fabricJdbcTemplate(@Qualifier("fabricDataSource") DataSource dataSource) {
//        return new JdbcTemplate(dataSource);
//    }
//}

package com.example.spring_boot_mysql_pgadmin.configuration;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories(
        basePackages = "com.example.spring_boot_mysql_pgadmin.repository.fabric",
        entityManagerFactoryRef = "fabricEntityManagerFactory",
        transactionManagerRef = "fabricTransactionManager"
)
public class FabricSQLConfiguration {

    @Bean(name = "fabricDataSource")
    @ConfigurationProperties("spring.datasource.fabricwarehouse")
    public DataSource fabricDataSource() {
        return new DriverManagerDataSource();
    }

    @Bean(name = "fabricEntityManagerFactory")
    public LocalContainerEntityManagerFactoryBean fabricEntityManagerFactory(
            EntityManagerFactoryBuilder builder,
            @Qualifier("fabricDataSource") DataSource dataSource) {
        return builder
                .dataSource(dataSource)
                .packages("com.example.spring_boot_mysql_pgadmin.entity")
                .persistenceUnit("fabric")
                .properties(hibernateProperties())
                .build();
    }

    @Bean(name = "fabricTransactionManager")
    public JpaTransactionManager fabricTransactionManager(
            @Qualifier("fabricEntityManagerFactory") EntityManagerFactory entityManagerFactory) {
        return new JpaTransactionManager(entityManagerFactory);
    }

    @Bean(name = "fabricJdbcTemplate")
    public JdbcTemplate fabricJdbcTemplate(@Qualifier("fabricDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    private Map<String, Object> hibernateProperties() {
        Map<String, Object> properties = new HashMap<>();
        properties.put("hibernate.hbm2ddl.auto", "update");
        properties.put("hibernate.show_sql", true);
        properties.put("hibernate.dialect", "org.hibernate.dialect.SQLServerDialect");
        return properties;
    }
}

