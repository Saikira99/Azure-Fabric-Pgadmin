package com.example.spring_boot_mysql_pgadmin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMysqlPgadminApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMysqlPgadminApplication.class, args);
	}

}
