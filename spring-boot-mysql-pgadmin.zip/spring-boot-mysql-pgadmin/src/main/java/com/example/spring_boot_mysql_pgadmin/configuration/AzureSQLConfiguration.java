package com.example.spring_boot_mysql_pgadmin.configuration;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
public class AzureSQLConfiguration {

    // DataSource bean for Azure SQL Database
    @Bean(name = "azureDataSource")
    @ConfigurationProperties("spring.datasource.azuresql")
    public DataSource azureDataSource() {
        return new DriverManagerDataSource();
    }

    // JdbcTemplate bean for Azure SQL Database
    @Bean(name = "azureJdbcTemplate")
    public JdbcTemplate azureJdbcTemplate(@Qualifier("azureDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }
}
