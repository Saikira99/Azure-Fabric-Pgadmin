package com.example.spring_boot_mysql_pgadmin.repository.fabricsql;

import com.example.spring_boot_mysql_pgadmin.entity.Technology;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

@Repository
public class TechnologyFabricSQLRepository {

    private static final Logger logger = LoggerFactory.getLogger(TechnologyFabricSQLRepository.class);
    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public TechnologyFabricSQLRepository(@Qualifier("fabricJdbcTemplate") JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    public List<Technology> findAll() {
        String sql = "SELECT * FROM technology";
        return jdbcTemplate.query(sql, this::mapRowToTechnology);
    }

    public Optional<Technology> findById(Long id) {
        String sql = "SELECT * FROM technology WHERE technology_id = ?";
        try {
            Technology technology = jdbcTemplate.queryForObject(sql, new Object[]{id}, this::mapRowToTechnology);
            return Optional.of(technology);
        } catch (EmptyResultDataAccessException e) {
            logger.warn("No technology found with ID: {}", id);
            return Optional.empty();
        }
    }

    public Technology save(Technology technology) {
        String sql = "INSERT INTO technology (technology_name, created_date, updated_date) VALUES (?, ?, ?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();

        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(sql, new String[]{"technology_id"});
            ps.setString(1, technology.getName());
            ps.setDate(2, java.sql.Date.valueOf(technology.getCreatedDate()));
            ps.setDate(3, java.sql.Date.valueOf(technology.getUpdatedDate()));
            return ps;
        }, keyHolder);

        technology.setId(keyHolder.getKey().longValue());
        logger.info("Saved technology with ID: {}", technology.getId());
        return technology;
    }

    public void update(Technology technology) {
        String sql = "UPDATE technology SET technology_name = ?, updated_date = ? WHERE technology_id = ?";
        int rowsUpdated = jdbcTemplate.update(sql, technology.getName(), technology.getUpdatedDate(), technology.getId());
        if (rowsUpdated > 0) {
            logger.info("Updated technology with ID: {}", technology.getId());
        } else {
            logger.warn("No technology found to update with ID: {}", technology.getId());
        }
    }

    public void deleteById(Long id) {
        String sql = "DELETE FROM technology WHERE technology_id = ?";
        int rowsDeleted = jdbcTemplate.update(sql, id);
        if (rowsDeleted > 0) {
            logger.info("Deleted technology with ID: {}", id);
        } else {
            logger.warn("No technology found to delete with ID: {}", id);
        }
    }

    private Technology mapRowToTechnology(ResultSet rs, int rowNum) throws SQLException {
        Technology technology = new Technology();
        technology.setId(rs.getLong("technology_id"));
        technology.setName(rs.getString("technology_name"));
        technology.setCreatedDate(rs.getDate("created_date").toLocalDate());
        technology.setUpdatedDate(rs.getDate("updated_date").toLocalDate());
        return technology;
    }
}
