package com.example.spring_boot_mysql_pgadmin.service;

import com.example.spring_boot_mysql_pgadmin.entity.Technology;
import com.example.spring_boot_mysql_pgadmin.repository.azuresql.TechnologyAzureSQLRepository;
import com.example.spring_boot_mysql_pgadmin.repository.fabricsql.TechnologyFabricSQLRepository;
import com.example.spring_boot_mysql_pgadmin.repository.mysql.MySQLJdbcTemplateRepository;
import com.example.spring_boot_mysql_pgadmin.repository.postgresql.PostgreSQLJdbcTemplateRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TechnologyService {

    @Autowired
    private MySQLJdbcTemplateRepository mysqlRepository; // Inject MySQL repository

    @Autowired
    private PostgreSQLJdbcTemplateRepository postgresqlRepository; // Inject PostgreSQL repository

    @Autowired
    private TechnologyAzureSQLRepository azureRepository; // Inject Azure SQL repository

    @Autowired
    private TechnologyFabricSQLRepository fabricRepository; // Inject Fabric SQL repository

    public Technology saveOrUpdate(Technology technology, DatabaseType dbType) {
        switch (dbType) {
            case POSTGRES:
                return postgresqlRepository.save(technology);
            case MYSQL:
                return mysqlRepository.save(technology);
            case AZURE:
                return azureRepository.save(technology);
            case FABRIC:
                return fabricRepository.save(technology);
            default:
                throw new IllegalArgumentException("Unsupported database type: " + dbType);
        }
    }

    public Optional<Technology> findById(Long id, DatabaseType dbType) {
        switch (dbType) {
            case POSTGRES:
                return postgresqlRepository.findById(id);
            case MYSQL:
                return mysqlRepository.findById(id);
            case AZURE:
                return azureRepository.findById(id);
            case FABRIC:
                return fabricRepository.findById(id);
            default:
                throw new IllegalArgumentException("Unsupported database type: " + dbType);
        }
    }

    public List<Technology> findAll(DatabaseType dbType) {
        switch (dbType) {
            case POSTGRES:
                return postgresqlRepository.findAll();
            case MYSQL:
                return mysqlRepository.findAll();
            case AZURE:
                return azureRepository.findAll();
            case FABRIC:
                return fabricRepository.findAll();
            default:
                throw new IllegalArgumentException("Unsupported database type: " + dbType);
        }
    }

    public void deleteById(Long id, DatabaseType dbType) {
        switch (dbType) {
            case POSTGRES:
                postgresqlRepository.deleteById(id);
                break;
            case MYSQL:
                mysqlRepository.deleteById(id);
                break;
            case AZURE:
                azureRepository.deleteById(id);
                break;
            case FABRIC:
                fabricRepository.deleteById(id);
                break;
            default:
                throw new IllegalArgumentException("Unsupported database type: " + dbType);
        }
    }

    // Enum for database types
    public enum DatabaseType {
        POSTGRES,
        MYSQL,
        AZURE,
        FABRIC
    }
}
