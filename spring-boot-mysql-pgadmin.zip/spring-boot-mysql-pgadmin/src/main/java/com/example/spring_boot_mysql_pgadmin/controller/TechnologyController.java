package com.example.spring_boot_mysql_pgadmin.controller;

import com.example.spring_boot_mysql_pgadmin.entity.Technology;
import com.example.spring_boot_mysql_pgadmin.service.TechnologyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/technologies")
public class TechnologyController {

    @Autowired
    private TechnologyService technologyService;

    @PostMapping("/{dbType}")
    public ResponseEntity<Technology> createTechnology(@RequestBody Technology technology, @PathVariable String dbType) {
        try {
            Technology savedTechnology = technologyService.saveOrUpdate(technology, TechnologyService.DatabaseType.valueOf(dbType.toUpperCase()));
            return new ResponseEntity<>(savedTechnology, HttpStatus.CREATED);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/{dbType}/{id}")
    public ResponseEntity<Technology> getTechnology(@PathVariable Long id, @PathVariable String dbType) {
        Optional<Technology> technology = technologyService.findById(id, TechnologyService.DatabaseType.valueOf(dbType.toUpperCase()));
        return technology.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    @GetMapping("/{dbType}")
    public ResponseEntity<List<Technology>> getAllTechnologies(@PathVariable String dbType) {
        List<Technology> technologies = technologyService.findAll(TechnologyService.DatabaseType.valueOf(dbType.toUpperCase()));
        return ResponseEntity.ok(technologies);
    }

    @PutMapping("/{dbType}")
    public ResponseEntity<Technology> updateTechnology(@RequestBody Technology technology, @PathVariable String dbType) {
        Optional<Technology> existingTechnology = technologyService.findById(technology.getId(), TechnologyService.DatabaseType.valueOf(dbType.toUpperCase()));

        if (existingTechnology.isPresent()) {
            Technology updatedTechnology = technologyService.saveOrUpdate(technology, TechnologyService.DatabaseType.valueOf(dbType.toUpperCase()));
            return ResponseEntity.ok(updatedTechnology);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

    @DeleteMapping("/{dbType}/{id}")
    public ResponseEntity<Void> deleteTechnology(@PathVariable Long id, @PathVariable String dbType) {
        technologyService.deleteById(id, TechnologyService.DatabaseType.valueOf(dbType.toUpperCase()));
        return ResponseEntity.noContent().build();
    }
}
