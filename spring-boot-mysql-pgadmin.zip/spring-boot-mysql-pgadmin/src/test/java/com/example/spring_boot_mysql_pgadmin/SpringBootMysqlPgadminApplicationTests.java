package com.example.spring_boot_mysql_pgadmin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMysqlPgadminApplicationTests {

	@Test
	void contextLoads() {
	}

}
